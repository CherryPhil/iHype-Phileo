var ListingModel = require('../models/listingModel');
var myDatabase = require('./sqlDatabase');
var sequelizeInstance = myDatabase.sequelizeInstance;

exports.openSell = function(req, res) {
    res.render("sell", {
        title: "Sell",
    });  
};

exports.openDisplay = function(req, res) {
    ListingModel.findAll().then(function(listingData){
        console.log(listingData);
        res.render("display", {
            title: "Display",
            datas: listingData,
        });
    })
};

exports.uploadSell = function(req, res) {
    var newListing = ({
        fashionGender: req.body.fashionGender,
        category: req.body.category,
        listingTitle: req.body.title,
        itemType: req.body.itemType,
        size: req.body.size,
        material: req.body.material,
        watchMovement: req.body.watchMovement,
        strapType: req.body.strapType,
        dial: req.body.dial,
        brand: req.body.brand,
        price: req.body.price,
        itemCondition: req.body.condition,
        description: req.body.description,
        evidence: req.body.evidence,
        meetup: req.body.meetup,
        delivery: req.body.delivery,
    });
    ListingModel.create(newListing)
    res.redirect("/sell");
};