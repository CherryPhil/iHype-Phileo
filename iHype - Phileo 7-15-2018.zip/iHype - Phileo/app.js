var express = require("express");
var app = express();
var bodyParser = require("body-parser");
var path = require('path');

// Phileo added Packages
var fs = require('fs');
var mime = require('mime');
var gravatar = require('gravatar');
var multer = require('multer')

var IMAGE_TYPES = ['image/jpeg', 'image/jpg', 'image/png'];

app.set('views', path.join(__dirname, 'server/views'));
app.set('view engine', 'ejs');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static(__dirname + '/public'));

var sugi = require("./server/controllers/sugiControl");

app.get("/login", sugi.openLogin);
app.get("/", sugi.openHome);
app.get("/terms&conditions", sugi.openTermsConditions);
app.get("/privacy", sugi.openPrivacy);

app.post("/login", sugi.login);
app.post("/register", sugi.register);

// Phileo
var phil = require("./server/controllers/philControl");

app.get("/sell", phil.openSell);
app.get("/display", phil.openDisplay);

app.post("/sell", phil.uploadSell);

app.listen(3000);