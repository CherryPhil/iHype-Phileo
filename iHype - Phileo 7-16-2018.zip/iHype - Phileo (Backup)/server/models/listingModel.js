var myDatabase = require('../controllers/sqlDatabase');
var sequelizeInstance = myDatabase.sequelizeInstance;
var Sequelize = myDatabase.Sequelize;

const listingDetails = sequelizeInstance.define('Listings', {
    listingNo: {
        type: Sequelize.INTEGER,
        autoIncrement: true,
        primaryKey: true
    },
    listingIMG1: {
        type: Sequelize.BLOB,
    },
    fashionGender:{
        type: Sequelize.STRING,
    },
    category: {
        type: Sequelize.STRING,
    },
    listingTitle: {
        type: Sequelize.STRING,
        trim: true,
        allowNull: false,
    },
    itemType:{
        type: Sequelize.STRING,
    },
    size: {
        type: Sequelize.STRING,
    },
    material: {
        type: Sequelize.STRING,
    },
    watchMovement:{
        type: Sequelize.STRING,
    },
    strapType: {
        type: Sequelize.STRING,
    },
    dial: {
        type: Sequelize.STRING,
    },
    brand: {
        type: Sequelize.STRING,
        trim: true,
    },
    price: {
        type: Sequelize.FLOAT,
        trim: true,
        allowNull: false
    },
    itemCondition: {
        type: Sequelize.STRING,
    },
    description: {
        type: Sequelize.STRING,
        trim: true,
    },
    evidence: {
        type: Sequelize.BLOB,
    },
    meetup: {
        type: Sequelize.STRING,
        defaultValue: "No",
    },
    delivery: {
        type: Sequelize.STRING,
        defaultValue: "No",
    },
    fav: {
        type: Sequelize.INTEGER,
        defaultValue: 0,
    }
});

listingDetails.sync({ force: false });

module.exports = sequelizeInstance.model('Listings', listingDetails);