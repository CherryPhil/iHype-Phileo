// Step 2 Activation
$("#img1").change(function(){
    if ($("#img1").val() != null){
        $("#step2").css("display", "block");
    }else if($("#img1").val() == null){
        $("#step2").css("display", "none");
    }
});

// Choosing Type of Gender (Step 3 Activation)
$("#fashionGender").change(function(){
    $("#listingMen").val("defaultMen");
    $("#listingWomen").val("defaultWomen");
    $("#step4").css("display", "none");
    if ($("#fashionGender").val() == "Men"){
        $("#listingMen").css("display", "block");
        $("#listingWomen").css("display", "none");
        $("#step3").css("display", "block");
    }else if(($("#fashionGender").val() == "Women")){
        $("#listingWomen").css("display", "block");
        $("#listingMen").css("display", "none");
        $("#step3").css("display", "block");
    }
});

// Choosing Men's Category (Step 4 Activation)
$("#listingMen").change(function(){
    $(".empty").val("empty");
    $(".size").val("emptySize");
    // Clear Men's Inputs
    $("#menClothing").css("display", "none")
    $("#menBags").css("display", "none")
    $("#menAccessories").css("display", "none")
    $("#menWatches").css("display", "none")
    $("#menFootwear").css("display", "none")
    $("#menBottomSize").css("display", "none");
    $("#menTopSize").css("display", "none");
    $("#menBagMaterial").css("display", "none");
    $("#watchMovement").css("display", "none");
    $("#watchStrapType").css("display", "none");
    $("#watchDial").css("display", "none");
    $("#menShoeSize").css("display", "none")
    // Clear Women's Inputs
    $("#womenClothing").css("display", "none");
    $("#womenDresses").css("display", "none");
    $("#womenBags").css("display", "none");
    $("#womenAccessories").css("display", "none");
    $("#womenJewelry").css("display", "none");
    $("#womenFootwear").css("display", "none");
    $("#womenTopSize").css("display", "none");
    $("#womenBottomSize").css("display", "none");
    $("#womenBagMaterial").css("display", "none");
    $("#womenShoeSize").css("display", "none");
    if ($("#listingWomen").val() == null){
        $("#step4").css("display", "block");
        if ($("#listingMen").val() == "Clothing"){
            console.log("Clothing");
            $("#menClothing").css("display", "block")

        }else if($("#listingMen").val() == "Bags"){
            console.log("Men's Bags");
            $("#menBags").css("display", "block")
            $("#menBagMaterial").css("display", "block");
            console.log("Men's Bags");
        }else if($("#listingMen").val() == "Accessories"){
            console.log("Men's Accessories");
            $("#menAccessories").css("display", "block")
        }else if($("#listingMen").val() == "Watches"){
            console.log("Men's Watches");
            $("#menWatches").css("display", "block")
            $("#watchMovement").css("display", "block");
            $("#watchStrapType").css("display", "block");
            $("#watchDial").css("display", "block");

        }else if($("#listingMen").val() == "Shoes"){
            console.log("Men's Shoes");
            $("#menFootwear").css("display", "block")
            $("#menShoeSize").css("display", "block")
        }
    }
});

// Choosing Men's Clothing
$("#menClothingType").change(function(){
    if ($("#menClothingType").val() == "Men's Tops"){
        $("#menTopSize").css("display", "block");
        $("#menBottomSize").css("display", "none");
        $(".size").val("emptySize");
        console.log("Men's Top")
    }else if ($("#menClothingType").val() == "Men's Bottoms"){
        $("#menBottomSize").css("display", "block");
        $("#menTopSize").css("display", "none");
        $(".size").val("emptySize");
        console.log("Men's Bottom")
    }
})

// Choosing Women's Category
$("#listingWomen").change(function(){
    $(".empty").val("empty");
    $(".size").val("emptySize");
    //Clear Women's Inputs
    $("#womenClothing").css("display", "none");
    $("#womenDresses").css("display", "none");
    $("#womenBags").css("display", "none");
    $("#womenAccessories").css("display", "none");
    $("#womenJewelry").css("display", "none");
    $("#womenFootwear").css("display", "none");
    $("#womenTopSize").css("display", "none");
    $("#womenBottomSize").css("display", "none");
    $("#womenBagMaterial").css("display", "none");
    $("#womenShoeSize").css("display", "none");
    // Clear Men's Inputs
    $("#menClothing").css("display", "none")
    $("#menBags").css("display", "none")
    $("#menAccessories").css("display", "none")
    $("#menWatches").css("display", "none")
    $("#menFootwear").css("display", "none")
    $("#menBottomSize").css("display", "none");
    $("#menTopSize").css("display", "none");
    $("#menBagMaterial").css("display", "none");
    $("#watchMovement").css("display", "none");
    $("#watchStrapType").css("display", "none");
    $("#watchDial").css("display", "none");
    $("#menShoeSize").css("display", "none")
    if ($("#listingMen").val() == null){
        $("#step4").css("display", "block");
        if ($("#listingWomen").val() == "Clothing"){
            $("#womenClothing").css("display", "block");
            console.log("Women's Clothing")
        }else if($("#listingWomen").val() == "Dresses"){
            $("#womenDresses").css("display", "block");
            console.log("Women's Dresses")
        }else if($("#listingWomen").val() == "Bags"){
            $("#womenBags").css("display", "block");
            $("#womenBagMaterial").css("display", "block");
            console.log("Women's Bags")
        }else if($("#listingWomen").val() == "Accessories"){
            $("#womenAccessories").css("display", "block");
            console.log("Women's Accessories")
        }else if($("#listingWomen").val() == "Jewllery"){
            $("#womenJewelry").css("display", "block");
            console.log("Women's Jewllery")
        }else if($("#listingWomen").val() == "Shoes"){
            $("#womenFootwear").css("display", "block");
            $("#womenShoeSize").css("display", "block");
            console.log("Women's Shoes")
        }
    }
});

// Choosing Women's Clothing
$("#womenClothingType").change(function(){
    if ($("#womenClothingType").val() == "Women's Tops"){
        $("#womenTopSize").css("display", "block");
        $("#womenBottomSize").css("display", "none");
        $(".size").val("emptySize");
        console.log("Women's Top")
    }else if ($("#womenClothingType").val() == "Women's Bottoms"){
        $("#womenBottomSize").css("display", "block");
        $("#womenTopSize").css("display", "none");
        $(".size").val("emptySize");
        console.log("Women's Bottom")
    }
})