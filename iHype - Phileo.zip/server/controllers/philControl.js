var ListingModel = require('../models/listingModel');
var myDatabase = require('./sqlDatabase');
var sequelizeInstance = myDatabase.sequelizeInstance;

exports.openSell = function(req, res) {
    res.render("sell", {
        title: "Sell",
    });  
};

exports.openDisplay = function(req, res) {
    ListingModel.findAll().then(function(listingData){
        console.log(listingData);
        res.render("display", {
            title: "Display",
            datas: listingData,
        });
    })
};

exports.uploadSell = function(req, res) {
    var newListing = ({
        listingTitle: req.body.title,
        size: req.body.size,
        brand: req.body.brand,
        price: req.body.price,
        itemCondition: req.body.condition,
        description: req.body.description,
        meetup: req.body.meetup,
        delivery: req.body.delivery,
    });
    ListingModel.create(newListing)
    res.redirect("/sell");
};