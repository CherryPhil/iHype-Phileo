var myDatabase = require('../controllers/sqlDatabase');
var sequelizeInstance = myDatabase.sequelizeInstance;
var Sequelize = myDatabase.Sequelize;

const listingDetails = sequelizeInstance.define('Listings', {
    listingTitle: {
        type: Sequelize.STRING,
        trim: true,
        allowNull: false,
        primaryKey: true
    },
    size: {
        type: Sequelize.STRING,
        allowNull: false
    },
    brand: {
        type: Sequelize.STRING,
        trim: true,
    },
    price: {
        type: Sequelize.INTEGER,
        trim: true,
        allowNull: false
    },
    itemCondition: {
        type: Sequelize.STRING,
        allowNull: false
    },
    description: {
        type: Sequelize.STRING,
        trim: true,
    },
    meetup: {
        type: Sequelize.STRING,
    },
    delivery: {
        type: Sequelize.STRING,
    }
});

listingDetails.sync({ force: false });

module.exports = sequelizeInstance.model('Listings', listingDetails);